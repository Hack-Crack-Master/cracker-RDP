>[+] Introduction:


This <a href="https://github.com/Hack-Crack-Master/cracker-RDP">RDP</a> Only Created by HackCrackMaster For Educational Purpose. If You Use It on Evil Purpose, Owner is Not Responsible For That. 
<br><br>

>[+] How To Use:

<pre>1 : Fork This Repository.
2 : Create a Account On <a href="https://ngrok.com">ngrok</a>
3 : Copy Your <a href="https://dashboard.ngrok.com/get-started/your-authtoken">Ngrok-Token</a>
4 : Go To Your Forked Repository's "Setting"
5 : Click on The "Sicret" Option
6 : Add Your <a href="RDP/sicret">Sicret</a>
7 : Go To Your Forked Repository's "Action"
8 : Select Your Workflow To "Cracker-RDP"
9 : Start Your Workflow<br>
	 After Starting Workflow
	>-----------------------<<br>
10: Go To <a href="https://ngrok.com">Ngrok</a>
11: Click On The <a href="https://dashboard.ngrok.com/endpoints">Endpoint</a> Option
11: And Click On The <a href="https://dashboard.ngrok.com/cloud-edge/endpoints">Status</a> Option
12: Copy The URL without "tcp://"
13: The Copied Link Like: 8.tcp.ngrok.io:15003
14: Go To Your RDP Using Software
15: Then Put Your Url

16: Put The Username: runneradmin
17: Put The Password: P@ssw0rd!

18: And Connect it

	>---------------------<
	   Your RDP is Ready
	>---------------------<
</pre>
<br>
<br>

>[+] Video Tutorial:

<br>

```

```

<br><br>
<!--
>[+] Repository Status:

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=Hack-Crack-Master&hide=contribs,prs)

-->
<br>

>[+] Contact Info:

<pre>    <a href="https://t.me/Hack_Crack_MASTER">Telegram</a> 
    <a href="https://github.com/Hack-Crack-Master">GitHub</a>
</pre>
